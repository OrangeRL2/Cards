
// Commands/Utility/pull.js
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { installLocalImageTransport } = require('../../utils/localizeInteractionEmbeds');
const { showSecReveal } = require('../../utils/secReveal');
const { showSavedPull } = require('../../utils/pullDisplayRecovery');
const { startPullDisplayGuard } = require('../../utils/pullDisplayGuard');
const path = require('path');
const User = require('../../models/User');
const halEvent = require('../../utils/halEvent');
const { candyForPack } = require('../../utils/halCandy');
const { isTrickBoo } = require('../../config/halTarot');
const halPull = require('../../utils/halPullEffects');

// === Quota + models (special-aware) ===
const PullQuota = require('../../utils/pullQuota'); // helper with getUpdatedQuota, constants
const PullQuotaModel = require('../../models/PullQuota'); // direct model for atomic updates
const SpecialPullGrant = require('../../models/SpecialPullGrant'); // active 24h grants
const PullLock = require('../../models/PullLock'); // per-user advisory lock (Mongo-backed)
const { resolveCardColor, getAttributeEmoji } = require('../../config/holomemColor'); // for attribute emojis in pull results
// === Draw functions ===
const { drawPack } = require('../../utils/newWeightedDraw'); // normal draw
const { drawPackBoss } = require('../../utils/drawPackBoss'); // boss-channel biased draw
const { getBossChannelDrawToken } = require('../../utils/bossPullBias');
const { isFrozen } = require('../../utils/freeze'); // for freeze status check in quota calculation
const {
  validateSummerPullChannel,
  rollSummerBonus,
} = require('../../utils/summerPullBonus');
const { getSummerBonusChance } = require('../../utils/summerEvent');
const {
  syChannelId,
  kunChannel,
  chanChannel,
  samaChannel,
  tanChannel,
  kunchansamatanSRplusChannel,
} = require('../../config.json');
// Tolerant import for special draw
let drawPackSpecial;
try {
  const specialModule = require('../../utils/drawPackSpecial');
  drawPackSpecial =
    (specialModule && (specialModule.drawPackSpecial || specialModule.default || specialModule));
  if (typeof drawPackSpecial !== 'function') {
    console.error('[pull] drawPackSpecial not available; special pulls will fallback to normal drawPack');
    drawPackSpecial = null;
  }
} catch (err) {
  console.error('[pull] failed to require drawPackSpecial', err);
  drawPackSpecial = null;
}

/**
 * Pity behavior:
 * - PITY_EXEMPT_IDS: do NOT increment pullsSinceLastSEC and do NOT force SEC.
 * - PITY_EXEMPT_IDS2: DO increment pullsSinceLastSEC, but NEVER force SEC.
 */
const PITY_EXEMPT_IDS = new Set([
  '1188023588926795827', // Quaso alt
  '1300468334474690583', // Quaso alt
  '1416081468794339479', // Quaso alt
  '953552994232852490',  // Eld alt
  '91103688415776768',   // Moomoo alt
  '647219814011502607',  // Moomoo alt
  '875533483051712543',  // Moomoo alt
]);

const PITY_EXEMPT_IDS2 = new Set([
''
]);
// === SY announcement ignore list ===
// Users in this set will NOT trigger the SY announcer message.
const SY_ANNOUNCE_EXEMPT_IDS = new Set([
  '511182422340272128',
]);

// === Kun/Chan/Sama/Tan SR+ announcement config ===
// Announce pulls from these four channels when the rarity is SR or higher.
const KUNCHANSAMATAN_SOURCE_CHANNEL_IDS = new Set([
  kunChannel,
  chanChannel,
  samaChannel,
  tanChannel,
].filter(Boolean));

const SR_PLUS_ANNOUNCE_RARITY_ORDER = [
  'XMAS', 'VAL', 'EAS', 'C', 'U', 'R', 'S', 'RR', 'OC', 'SR', 'COL', 'OSR',
  'P', 'SP', 'UP', 'SY', 'UR', 'OUR', 'HR', 'BDAY', 'SEC', 'ORI', 'EV',
];
const SR_PLUS_THRESHOLD_INDEX = SR_PLUS_ANNOUNCE_RARITY_ORDER.indexOf('SR');

function isSrPlusRarity(rarity) {
  const idx = SR_PLUS_ANNOUNCE_RARITY_ORDER.indexOf(String(rarity ?? '').toUpperCase());
  return idx >= SR_PLUS_THRESHOLD_INDEX && SR_PLUS_THRESHOLD_INDEX >= 0;
}
// In-process guard still useful for same-interaction re-entry,
// but it doesn't stop two different interactions from the same user.
const inFlightInteractions = new Map();

const IMAGE_BASE = process.env.IMAGE_BASE || 'http://152.69.195.48/images';

const PAGE_TIMEOUT_MS = 2 * 60 * 1000; // 2 minutes
const DEFAULT_GIF_DURATION_MS = 1200; // base animation delay for first/solo pulls


const gifs = [
  'https://media.discordapp.net/attachments/1046811248647475302/1437428233086963774/ppp.gif',
  'https://media.discordapp.net/attachments/1046811248647475302/1437428255249535096/ag.gif',
  'https://media.discordapp.net/attachments/1046811248647475302/1437428283217149962/hhw.gif',
  'https://media.discordapp.net/attachments/1046811248647475302/1437428356617338891/Roselia.gif',
  'https://media.discordapp.net/attachments/1046811248647475302/1437428386988556438/MyGO.gif',
  'https://cdn.discordapp.com/attachments/802431770023952406/1438516550628937819/Morf.gif',
  'https://cdn.discordapp.com/attachments/986110973574283265/1446127876339400724/ave_mujica.gif',
  'https://cdn.discordapp.com/attachments/986110973574283265/1441054422401683626/Pasupare.gif',
  'https://cdn.discordapp.com/attachments/802431770023952406/1443593296189456486/ras.gif'
];


function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// --- Mongo-backed per-user advisory lock + queue ---
async function acquirePullLock(userId, owner, ttlMs = 120000) {
  const now = new Date();
  const until = new Date(now.getTime() + ttlMs);
  try {
    const res = await PullLock.updateOne(
      // Acquire if: no lock, or expired, or we already own it (re-entrant).
      { userId, $or: [{ until: { $lt: now } }, { owner }] },
      { $set: { userId, owner, until } },
      { upsert: true }
    ).exec();
    return Boolean(res.matchedCount > 0 || res.upsertedCount > 0);
  } catch {
    return false; // someone else is holding it right now
  }
}

async function announceSyPull(interaction, pulledCards) {
  // Skip announcements for ignored users
  if (SY_ANNOUNCE_EXEMPT_IDS.has(interaction.user.id)) return;

  const arr = Array.isArray(pulledCards) ? pulledCards : [pulledCards];
  if (!arr.length) return;

  // Only SY cards
  const syCards = arr.filter(c => String(c?.rarity).toUpperCase() === 'SY');
  if (!syCards.length) return;

  const channelId = syChannelId;
  if (!channelId) return;

  const channel = await interaction.client.channels.fetch(channelId).catch(() => null);
  if (!channel || !channel.isTextBased()) return;

  const userTag = `${interaction.user}`; // mention the puller

  for (const card of syCards) {
    const safeName = String(card?.name ?? 'Unknown').replace(/@/g, '@\u200b');

    // Attribute/color emoji (same logic as your embed display)
    const cc = resolveCardColor(safeName, 'SY');
    const emoji = cc ? getAttributeEmoji(cc) : '';
    const tag = emoji ? ` ${emoji}` : '';

    await channel.send(`**[SY]** **${safeName}**${tag} has been pulled by ${userTag}`);
  }
}


async function announceKunChanSamaTanSrPlusPull(interaction, pulledCards, pullMessage = null) {
  if (!KUNCHANSAMATAN_SOURCE_CHANNEL_IDS.has(interaction.channelId)) return;

  const arr = Array.isArray(pulledCards) ? pulledCards : [pulledCards];
  const srPlusCards = arr.filter(c => isSrPlusRarity(c?.rarity));
  if (!srPlusCards.length) return;

  const channelId = kunchansamatanSRplusChannel;
  if (!channelId) return;

  const channel = await interaction.client.channels.fetch(channelId).catch(() => null);
  if (!channel || !channel.isTextBased()) return;

  const userTag = `${interaction.user}`;
  const jumpUrl = pullMessage?.url;

  const lines = srPlusCards.map(card => {
    const rarity = String(card?.rarity ?? 'Unknown').toUpperCase();
    const safeName = String(card?.displayName ?? card?.name ?? 'Unknown').replace(/@/g, '@\u200b');
    const cc = resolveCardColor(safeName, rarity);
    const emoji = cc ? getAttributeEmoji(cc) : '';
    const tag = emoji ? ` ${emoji}` : '';
    return `**[${rarity}]** **${safeName}**${tag}`;
  });

  const content = [
    `SR+ pull in ${interaction.channel} by ${userTag}!`,
    ...lines,
    jumpUrl ? `Original pull: ${jumpUrl}` : null,
  ].filter(Boolean).join('\n');

  const payload = { content };

  // Discord bots cannot truly "forward" an existing message in every server/client like a user can,
  // so this adds a direct jump link button to the original pull message when Discord gives us the URL.
  if (jumpUrl) {
    payload.components = [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel('Jump to pull')
          .setStyle(ButtonStyle.Link)
          .setURL(jumpUrl)
      )
    ];
  }

  await channel.send(payload).catch(err => console.error('[SR+ announce] failed:', err));
}

async function releasePullLock(userId, owner) {
  try { await PullLock.deleteOne({ userId, owner }).exec(); } catch {}
}

// Waits for lock without ever showing a rejection to the user (queue behavior).
async function waitForPullLock(userId, owner, timeoutMs = 20000, retryMs = 50) {
  const start = Date.now();
  while (true) {
    const ok = await acquirePullLock(userId, owner, 120000);
    if (ok) return true;
    if (Date.now() - start > timeoutMs) return false;
    await sleep(retryMs);
  }
}

// === Special + quota helpers ===
async function findMostRecentActiveSpecial() {
  try {
    return await SpecialPullGrant
      .findOne({ active: true, expiresAt: { $gt: new Date() } })
      .sort({ createdAt: -1 })
      .lean();
  } catch (err) {
    console.error('[findMostRecentActiveSpecial] error', err);
    return null;
  }
}

async function ensureUserSpecialKey(userId, labelKey, defaultVal) {
  try {
    await PullQuotaModel.updateOne(
      { userId, [`specialPulls.${labelKey}`]: { $exists: false } },
      { $set: { [`specialPulls.${labelKey}`]: defaultVal } }
    ).exec();
    return true;
  } catch (err) {
    console.error('[ensureUserSpecialKey] updateOne failed', { userId, labelKey, err });
    return false;
  }
}

/**
 * Authoritative pulls consumption.
 * (Special path already uses atomic $inc. We'll harden timed-only to use $inc too.)
 */

async function consumePulls(discordUserId, amount, allowEvent, specialLabel = null, options = {}) {

  const frozen = Boolean(options?.frozen || options?.isFrozen);

  function computeNextRefill(doc) {
    if (!doc) return null;

    // ✅ frozen cooldown is always "15 minutes remaining"
    if (frozen) return PullQuota.REFILL_INTERVAL_MS;

    // If already full, no timer
    if ((doc.pulls ?? 0) >= PullQuota.MAX_STOCK) return 0;

    const now = Date.now();
    const last = doc.lastRefill ? new Date(doc.lastRefill).getTime() : now;
    return Math.max(0, PullQuota.REFILL_INTERVAL_MS - (now - last));
  }


  // --- Special path (kept as-is; already atomic) ---
  if (specialLabel) {
    const labelKey = String(specialLabel);
    const grant = await SpecialPullGrant
      .findOne({ label: labelKey, active: true, expiresAt: { $gt: new Date() } })
      .lean();

    if (!grant) {
      return {
        success: false,
        consumedFromEvent: 0, consumedFromTimed: 0, consumedFromSpecial: 0,
        doc: null, remainingEvent: 0, remainingTimed: 0, remainingSpecial: 0,
        nextRefillInMs: null, reason: 'no_active_special'
      };
    }

    const { doc: initialDoc } = await PullQuota.getUpdatedQuota(discordUserId, options);
    if (!initialDoc) {
      try {
        const init = { userId: discordUserId, pulls: 0, eventPulls: 0, specialPulls: {} };
        init.specialPulls[labelKey] = grant.pullsPerUser;
        await PullQuotaModel.updateOne(
          { userId: discordUserId },
          { $setOnInsert: init },
          { upsert: true }
        ).catch(() => null);
      } catch {}
    }

    await ensureUserSpecialKey(discordUserId, labelKey, grant.pullsPerUser);

    const { doc } = await PullQuota.getUpdatedQuota(discordUserId, { frozen });
    if (!doc) {
      return {
        success: false,
        consumedFromEvent: 0, consumedFromTimed: 0, consumedFromSpecial: 0,
        doc: null, remainingEvent: 0, remainingTimed: 0, remainingSpecial: 0,
        nextRefillInMs: null, reason: 'no_quota_doc'
      };
    }

    let remainingSpecial = 0;
    try {
      if (doc.specialPulls && typeof doc.specialPulls.get === 'function') {
        remainingSpecial = Number(doc.specialPulls.get(labelKey) ?? 0);
      } else if (doc.specialPulls && Object.prototype.hasOwnProperty.call(doc.specialPulls, labelKey)) {
        remainingSpecial = Number(doc.specialPulls[labelKey] ?? 0);
      }
    } catch { remainingSpecial = 0; }

    if (remainingSpecial < amount) {
      return {
        success: false,
        consumedFromEvent: 0, consumedFromTimed: 0, consumedFromSpecial: 0,
        doc, remainingEvent: doc.eventPulls ?? 0, remainingTimed: doc.pulls ?? 0, remainingSpecial,
        nextRefillInMs: computeNextRefill(doc), reason: 'no_special_remaining'
      };
    }

    const toConsume = amount;

    try {
      const incObj = {};
      incObj[`specialPulls.${labelKey}`] = -toConsume;
      await PullQuotaModel.updateOne({ userId: discordUserId }, { $inc: incObj }).exec();
    } catch (e) {
      console.error('[consumePulls] special decrement failed', e);
      return {
        success: false,
        consumedFromEvent: 0, consumedFromTimed: 0, consumedFromSpecial: 0,
        doc, remainingEvent: doc.eventPulls ?? 0, remainingTimed: doc.pulls ?? 0, remainingSpecial,
        nextRefillInMs: computeNextRefill(doc), reason: 'special_consume_failed'
      };
    }

    const { doc: afterDoc } = await PullQuota.getUpdatedQuota(discordUserId, options);

    let afterRemainingSpecial = 0;
    if (afterDoc) {
      if (afterDoc.specialPulls && typeof afterDoc.specialPulls.get === 'function') {
        afterRemainingSpecial = Number(afterDoc.specialPulls.get(labelKey) ?? 0);
      } else if (afterDoc.specialPulls && Object.prototype.hasOwnProperty.call(afterDoc.specialPulls, labelKey)) {
        afterRemainingSpecial = Number(afterDoc.specialPulls[labelKey] ?? 0);
      }
    }

    return {
      success: true,
      consumedFromEvent: 0, consumedFromTimed: 0, consumedFromSpecial: toConsume,
      doc: afterDoc ?? null,
      remainingEvent: afterDoc ? (afterDoc.eventPulls ?? 0) : 0,
      remainingTimed: afterDoc ? (afterDoc.pulls ?? 0) : 0,
      remainingSpecial: afterRemainingSpecial,
      nextRefillInMs: computeNextRefill(afterDoc),
      reason: null
    };
  }

  // --- Non-special path (original logic + atomic $inc for timed-only) ---
  const { doc } = await PullQuota.getUpdatedQuota(discordUserId, { frozen });
  if (!doc) {
    return {
      success: false,
      consumedFromEvent: 0, consumedFromTimed: 0, consumedFromSpecial: 0,
      doc: null, remainingEvent: 0, remainingTimed: 0, remainingSpecial: null, nextRefillInMs: null
    };
  }

  if (allowEvent) {
    const needed = amount;
    let consumedFromEvent = 0;
    let consumedFromTimed = 0;

    if ((Number(doc.eventPulls) || 0) + (Number(doc.pulls) || 0) < needed) {
      return {
        success: false,
        consumedFromEvent: 0, consumedFromTimed: 0, consumedFromSpecial: 0,
        doc, remainingEvent: doc.eventPulls ?? 0, remainingTimed: doc.pulls ?? 0,
        remainingSpecial: null, nextRefillInMs: computeNextRefill(doc)
      };
    }

    if (doc.eventPulls >= needed) {
      consumedFromEvent = needed;
      doc.eventPulls -= consumedFromEvent;
    } else if (doc.eventPulls > 0) {
      consumedFromEvent = doc.eventPulls;
      doc.eventPulls = 0;
    }

    const remainingNeeded = needed - consumedFromEvent;

    if (remainingNeeded > 0 && doc.pulls > 0) {
      consumedFromTimed = Math.min(doc.pulls, remainingNeeded);
      const wasFullBefore = doc.pulls >= PullQuota.MAX_STOCK;
      doc.pulls = Math.max(0, doc.pulls - consumedFromTimed);
      if (wasFullBefore && consumedFromTimed > 0) doc.lastRefill = new Date();
    }

    await doc.save();
    const nextIn = computeNextRefill(doc);
    const success = (consumedFromEvent + consumedFromTimed) === needed;

    return {
      success,
      consumedFromEvent,
      consumedFromTimed,
      consumedFromSpecial: 0,
      doc,
      remainingEvent: doc.eventPulls,
      remainingTimed: doc.pulls,
      remainingSpecial: null,
      nextRefillInMs: nextIn
    };
  }

  // Timed-only path: atomic decrement
  const dec = await PullQuotaModel.updateOne(
    { userId: discordUserId, pulls: { $gte: amount } },
    [
      {
        $set: {
          lastRefill: {
            $cond: [
              { $eq: ["$pulls", PullQuota.MAX_STOCK] },
              new Date(),
              "$lastRefill"
            ]
          }
        }
      },
      {
        $set: {
          pulls: { $subtract: ["$pulls", amount] }
        }
      }
    ]
  ).exec();

  if (dec && dec.modifiedCount === 1) {
    const { doc: afterDoc } = await PullQuota.getUpdatedQuota(discordUserId, options);
    const nextIn = computeNextRefill(afterDoc);
    return {
      success: true,
      consumedFromEvent: 0, consumedFromTimed: amount, consumedFromSpecial: 0,
      doc: afterDoc ?? null,
      remainingEvent: afterDoc ? (afterDoc.eventPulls ?? 0) : 0,
      remainingTimed: afterDoc ? (afterDoc.pulls ?? 0) : 0,
      remainingSpecial: null,
      nextRefillInMs: nextIn
    };
  }

  const nextIn = computeNextRefill(doc);
  return {
    success: false,
    consumedFromEvent: 0, consumedFromTimed: 0, consumedFromSpecial: 0,
    doc, remainingEvent: doc.eventPulls, remainingTimed: doc.pulls,
    remainingSpecial: null, nextRefillInMs: nextIn
  };
}

// --- Helpers for escaping/link-safe text ---
function escapeRegex(s) {
  return s.replace(/[.*+?^${}()\n[\]\\]/g, '\\$&');
}
function escapeLinkText(text) {
  return text.replace(/(_*\[\~`>#+\-=|{}.!\\])/g, '\\$1');
}


async function getInteractionRoleIds(interaction) {
  const cachedRoles = interaction.member?.roles?.cache;
  if (cachedRoles && typeof cachedRoles.keys === 'function') return [...cachedRoles.keys()].map(String);
  if (Array.isArray(interaction.member?.roles)) return interaction.member.roles.map(String);
  if (interaction.guild && interaction.user?.id) {
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (member?.roles?.cache) return [...member.roles.cache.keys()].map(String);
  }
  return [];
}


function getPullChannelContext(interaction) {
  const channel = interaction?.channel || null;
  const inThread = Boolean(channel?.isThread?.());
  const validationChannelId = inThread && channel?.parentId
    ? String(channel.parentId)
    : String(interaction?.channelId || '');

  return {
    inThread,
    validationChannelId,
    rateMultiplier: inThread ? 0.00 : 1.0,
  };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('multi-pull')
    .setDescription('Spend multiple pulls to draw up to 50 packs of cards.')
    .addIntegerOption(option =>
      option.setName('amount')
        .setDescription('Number of packs to pull (1-50).')
        .setMinValue(1)
        .setMaxValue(50)
        .setRequired(true)
    )
    .addBooleanOption(option =>
      option.setName('event')
        .setDescription('Allow using event pulls if timed pulls are insufficient (true or false).')
        .setRequired(false)
    )
    .addBooleanOption(option =>
      option.setName('special')
        .setDescription('Use the currently active special pulls (if any).')
        .setRequired(false)
    ),

  requireOshi: true,

  async execute(interaction) {
    installLocalImageTransport(interaction);
    const displayGuard = startPullDisplayGuard(interaction, 'multi-pull');
    // Claim this interaction before any async work, so duplicate deliveries do
    // not create a second placeholder or replace a completed result with a GIF.
    if (inFlightInteractions.has(interaction.id)) return;
    inFlightInteractions.set(interaction.id, Date.now());

    // Never charge or award a pull when its Discord response couldn't start.
    try { await interaction.deferReply(); }
    catch (err) {
      console.error('[pull] failed to acknowledge interaction:', err);
      inFlightInteractions.delete(interaction.id);
      return;
    }

    // Show loading GIF right away (users see something even if they spam).
    const gifUrl = gifs[Math.floor(Math.random() * gifs.length)];
    const loadingEmbed = new EmbedBuilder().setTitle('*PULLING...*').setColor(0x00BBFF).setImage(gifUrl);

    let gifShownAt = Date.now();
    try { await interaction.editReply({ content: null, embeds: [loadingEmbed], components: [] }); gifShownAt = Date.now(); } catch {}


    displayGuard.stage('loading shown / checking account');
    const discordUserId = interaction.user.id;
    const lockOwner = interaction.id;
    // --- Freeze check (users/roles) ---
    const guild = interaction.guild;
    let member = interaction.member;

    if (guild && (!member || !member.roles?.cache)) {
      member = await guild.members.fetch(discordUserId).catch(() => null);
    }

const frozen = isFrozen(discordUserId, member);
    // ✅ : pity mode flags
    const pityNoTrack = PITY_EXEMPT_IDS.has(discordUserId);
    const pityNoForce = pityNoTrack || PITY_EXEMPT_IDS2.has(discordUserId);

    // Try to get the lock immediately; if not, wait (queue) without showing any "please wait" error.
    displayGuard.stage('waiting for MongoDB pull lock');
    let acquiredFast = await acquirePullLock(discordUserId, lockOwner, 120000);
    let queued = false;
    if (!acquiredFast) {
      queued = true; // this pull is queued behind another from the same user
      acquiredFast = await waitForPullLock(discordUserId, lockOwner, /*timeoutMs*/ 20000, /*retryMs*/ 50);
      if (!acquiredFast) {
        // Extremely rare: still couldn't get the lock after 20s.
        // Show a graceful error and exit without consuming a pull.
        const ANIM_MS = queued ? 0 : DEFAULT_GIF_DURATION_MS;
        const elapsed = Date.now() - gifShownAt;
        if (elapsed < ANIM_MS) await sleep(ANIM_MS - elapsed);

        try {
          await interaction.editReply({
            embeds: [], attachments: [],
            content: 'Server is busy handling your previous pulls. Please try again in a moment.',
            components: []
          });
        } catch {}

        inFlightInteractions.delete(interaction.id);
        return;
      }
    }

    // Maintain the Mongo lock until the DB transaction has finished. A fixed
    // expiry alone is unsafe for large inventories / Judgement double-card packs.
    displayGuard.stage('lock acquired / checking quota and event rules');
    const lockHeartbeat = setInterval(() => {
      void PullLock.updateOne(
        { userId: discordUserId, owner: lockOwner },
        { $set: { until: new Date(Date.now() + 120_000) } }
      ).exec().then(result => {
        if (!result.matchedCount) console.warn(`[pull-lock] Lease lost for ${discordUserId}`);
      }).catch(err => console.error('[pull-lock] Lease refresh failed:', err));
    }, 30_000);
    lockHeartbeat.unref?.();

    // From here, we own the lock. Always release it at the end.
    let lockReleased = false;
    const release = async () => {
      if (!lockReleased) {
        lockReleased = true;
        clearInterval(lockHeartbeat);
        await releasePullLock(discordUserId, lockOwner);
      }
    };

    // If this was queued, skip the GIF delays to speed up results.
    const ANIM_MS = queued ? 0 : DEFAULT_GIF_DURATION_MS;
    let resultDisplayed = false;

    try {
      const amount = interaction.options.getInteger('amount', true);
      const allowEvent = Boolean(interaction.options.getBoolean('event'));
      const useSpecial = Boolean(interaction.options.getBoolean('special'));
      const pullChannelContext = getPullChannelContext(interaction);

      // --- Summer island restriction ---
      // This runs before quota consumption, so wrong-channel attempts cost nothing.
      const summerRoleIds = await getInteractionRoleIds(interaction);

      const summerContext = await validateSummerPullChannel({

        userId: discordUserId,

        channelId: pullChannelContext.validationChannelId,

        roleIds: summerRoleIds,

      });

      if (!summerContext.allowed) {
        inFlightInteractions.delete(interaction.id);

        const elapsed = Date.now() - gifShownAt;
        if (elapsed < ANIM_MS) {
          await sleep(ANIM_MS - elapsed);
        }

        await interaction.editReply({
          content: summerContext.message,
          embeds: [],
          components: [],
        }).catch(() => null);

        await release();
        return;
      }

      // --- Resolve active special grant (if requested) ---
      let consumeLabelKey = null; // quota key (grant.label)
      let specialDrawToken = null; // draw token (grant.displayLabel ?? label)
      let resolvedGrant = null;

      if (useSpecial) {
        try {
          const grant = await findMostRecentActiveSpecial();
          if (!grant || !grant.label) {
            inFlightInteractions.delete(interaction.id);
            const elapsed = Date.now() - gifShownAt;
            if (elapsed < ANIM_MS) await sleep(ANIM_MS - elapsed);

            const embed = new EmbedBuilder()
              .setTitle('No active special pulls')
              .setColor(0xFF5555)
              .setDescription('There is no active special pull event right now.');
            await interaction.editReply({ embeds: [embed], components: [] }).catch(() => null);
            await release();
            return;
          }

          consumeLabelKey = String(grant.label);
          specialDrawToken = String(grant.displayLabel ?? grant.label);
          resolvedGrant = grant;

          try {
            loadingEmbed.setFooter({ text: `Active special: ${grant.displayLabel ?? grant.label}` });
            loadingEmbed.setColor(0x87CEFA);
            await interaction.editReply({ embeds: [loadingEmbed] }).catch(() => null);
          } catch {}
        } catch (err) {
          console.error('failed to resolve active special grant:', err);
          inFlightInteractions.delete(interaction.id);

          const elapsed = Date.now() - gifShownAt;
          if (elapsed < ANIM_MS) await sleep(ANIM_MS - elapsed);

          await interaction.editReply({ embeds: [], attachments: [], content: 'Failed to check special pulls. Please try again later.', components: [] }).catch(() => null);
          await release();
          return;
        }
      }

      // --- Boss-channel detection (non-fatal) ---
      let bossChannelBias = null;
      try {
        bossChannelBias = await getBossChannelDrawToken(interaction);
        if (bossChannelBias && bossChannelBias.biased && bossChannelBias.drawToken) {
          // If this is a special attempt in a boss channel, block it per requirement
          if (useSpecial) {
            inFlightInteractions.delete(interaction.id);

            const elapsed = Date.now() - gifShownAt;
            if (elapsed < ANIM_MS) await sleep(ANIM_MS - elapsed);

            const embed = new EmbedBuilder()
              .setTitle('Special pulls are not allowed here')
              .setColor(0xFF5555)
              .setDescription('Special pulls are not allowed in this channel.');
            await interaction.editReply({ embeds: [embed], components: [] }).catch(() => null);
            await release();
            return;
          }

          // Cosmetic hint on loading embed when boss bias applies
          try {
            loadingEmbed.setFooter({ text: `The algorithm has found: ${bossChannelBias.drawToken}!` });
            loadingEmbed.setColor(0xFFD700);
            await interaction.editReply({ embeds: [loadingEmbed] }).catch(() => null);
          } catch {}
        }
      } catch (e) {
        console.warn('[pull] boss-channel bias check failed', e);
        bossChannelBias = { drawToken: null, biased: false };
      }

      // HAL effects are read BEFORE charging quota so Hierophant can spend 2 pulls.
      const halTarot = await halEvent.getEffect(discordUserId);
      const halContext = await halPull.createContext(discordUserId, halTarot);
      halContext.drawMode = useSpecial ? 'special' : 'normal';
      const halRateFactor = halTarot?.number === 7 ? 2 : (halTarot?.number === 16 ? 0.5 : 1);
      const halPullCostMultiplier = halTarot?.number === 5 ? 2 : 1;
      const halMagicianReady = halTarot?.number === 1 && !(await halEvent.getState(discordUserId))?.magicianUsed;

      displayGuard.stage('consuming pull quota');
      // --- Authoritative: consume pulls BEFORE drawing ---
      let consumeResult;
      try {
        const consumeLabel = consumeLabelKey ?? null;
        consumeResult = await consumePulls(discordUserId, amount * halPullCostMultiplier, allowEvent, consumeLabel, { frozen });
      } catch (err) {
        console.error('consumePulls error (pre-draw):', err);
        inFlightInteractions.delete(interaction.id);

        const elapsed = Date.now() - gifShownAt;
        if (elapsed < ANIM_MS) await sleep(ANIM_MS - elapsed);

        await interaction.editReply({ embeds: [], attachments: [], content: 'Failed to consume pulls. Please try again later.', components: [] }).catch(() => null);
        await release();
        return;
      }

      if (!consumeResult.success) {
        let nextRefillText = 'Refill scheduled';
        if (typeof consumeResult.nextRefillInMs === 'number' && consumeResult.nextRefillInMs > 0) {
          nextRefillText = `<t:${Math.floor((Date.now() + consumeResult.nextRefillInMs) / 1000)}:R>`;
        } else if (consumeResult.nextRefillInMs === 0) {
          nextRefillText = 'Ready';
        }

        if (consumeLabelKey) {
          const embed = new EmbedBuilder()
            .setTitle('Not enough special pulls available')
            .setColor(0x87CEFA)
            .addFields(
              { name: 'Special pulls remaining', value: `${consumeResult.remainingSpecial ?? 0}`, inline: true },
              { name: 'Next timed pull', value: nextRefillText, inline: true }
            );

          inFlightInteractions.delete(interaction.id);

          const elapsed = Date.now() - gifShownAt;
          if (elapsed < ANIM_MS) await sleep(ANIM_MS - elapsed);

          await interaction.editReply({ embeds: [embed], components: [] }).catch(() => null);
          await release();
          return;
        }

        const embed = new EmbedBuilder()
          .setTitle('Not enough pulls available')
          .setColor(0xFF5555)
          .addFields(
            { name: 'Timed pulls', value: `${consumeResult.remainingTimed ?? 0}`, inline: true },
            { name: 'Event pulls', value: `${consumeResult.remainingEvent ?? 0}`, inline: true },
            { name: 'Next timed pull', value: nextRefillText, inline: true },
          );

        if (consumeResult.reason === 'no_active_special') {
          embed.addFields({ name: 'Special pulls', value: `No active special available`, inline: false });
        } else if (consumeResult.reason === 'no_special_remaining') {
          embed.addFields({ name: 'Special pulls', value: `No special pulls remaining`, inline: false });
        }

        inFlightInteractions.delete(interaction.id);

        const elapsed = Date.now() - gifShownAt;
        if (elapsed < ANIM_MS) await sleep(ANIM_MS - elapsed);

        await interaction.editReply({ embeds: [embed], components: [] }).catch(() => null);
        await release();
        return;
      }

      // Ensure user exists before reading pity
      await User.updateOne(
        { id: discordUserId },
        { $setOnInsert: { id: discordUserId, cards: [], points: 0, pullsSinceLastSEC: 0 } },
        { upsert: true }
      );

      // --- SEC pity counter (read before draw) ---
      let pullsSinceLastSEC = 0;
      let forceSEC = false;

      if (!pityNoTrack) {
        try {
          const u = await User.findOne({ id: discordUserId }, { pullsSinceLastSEC: 1 }).lean();
          pullsSinceLastSEC = Number(u?.pullsSinceLastSEC ?? 0);

          // ✅ Force only if user is NOT in no-force mode
          forceSEC = (!pityNoForce) && halTarot?.number !== 13 && (pullsSinceLastSEC >= 1999); // next pull is the 2000th
        } catch (e) {
          console.error('[pity] failed to read pullsSinceLastSEC:', e);
          pullsSinceLastSEC = 0;
          forceSEC = false;
        }
      } else {
        // Fully exempt: no tracking and no force
        pullsSinceLastSEC = 0;
        forceSEC = false;
      }

      displayGuard.stage('drawing multi-pull packs');
      // --- Draw all requested packs. Pity is evaluated sequentially for every pack. ---
      const packs = [];
      // Track each independent draw before Judgement merges two packs.
      let candyEarned = 0;
      let runningSinceSEC = pullsSinceLastSEC;
      try {
        for (let packIndex = 0; packIndex < amount; packIndex += 1) {
          forceSEC = (halMagicianReady && packIndex === 0) || ((!pityNoForce) && halTarot?.number !== 13 && (runningSinceSEC >= 1999));
          let drawnPack;
          if (!useSpecial && bossChannelBias && bossChannelBias.biased && bossChannelBias.drawToken) {
            drawnPack = await drawPackBoss(discordUserId, bossChannelBias.drawToken, {
            forceSEC,
            rateMultiplier: pullChannelContext.rateMultiplier * halRateFactor,
            summerIsland: summerContext?.summerActive ? summerContext.island : null,
          });
          } else if (useSpecial && drawPackSpecial && specialDrawToken) {
            drawnPack = await drawPackSpecial(discordUserId, specialDrawToken, {
            forceSEC,
            rateMultiplier: pullChannelContext.rateMultiplier * halRateFactor,
          });
          } else {
            drawnPack = await drawPack(discordUserId, null, {
            forceSEC,
            rateMultiplier: pullChannelContext.rateMultiplier * halRateFactor,
            summerIsland: summerContext?.summerActive
              ? summerContext.island
              : null,
          });
          }

          drawnPack = halPull.modifyPack(drawnPack, halContext, { forceMagician: halMagicianReady && packIndex === 0 });
          candyEarned += candyForPack(drawnPack);
          // Each pack independently rolls for an optional ninth SUN card.
          const summerBonus = halTarot?.number === 13 ? null : rollSummerBonus({
          summerContext,
          chance: getSummerBonusChance(),
        });

          if (summerBonus) {
            drawnPack.push(summerBonus);
          }

          if (halTarot?.number === 20) {
            const second = await halPull.halIndependentSecondPack({ userId: discordUserId, useSpecial, drawPackSpecial,
        specialToken: specialDrawToken, bossBias: bossChannelBias, bossDraw: drawPackBoss,
        normalDraw: drawPack, rateMultiplier: pullChannelContext.rateMultiplier * halRateFactor,
        summerIsland: summerContext?.summerActive ? summerContext.island : null, context: halContext });
            candyEarned += candyForPack(second);
            drawnPack.push(...second);
          }
          const halBooDrop = halTarot?.number === 13 ? null : halEvent.rollBooExtraSlot();
          if (halBooDrop) drawnPack.push(halBooDrop);
          packs.push(drawnPack);
          if (!pityNoTrack) {
            const packHasSEC = drawnPack.some(item => String(item?.rarity ?? '').toUpperCase() === 'SEC');
            runningSinceSEC = halPull.pityAfter(runningSinceSEC, packHasSEC, halTarot?.number);
          }
        }
      } catch (err) {
        console.error('multi-pull draw error after consume:', err);

        // Refund on failure
        try {
          const { doc } = await PullQuota.getUpdatedQuota(discordUserId, { frozen });
          if (doc) {
            const inc = {};
            if (consumeResult.consumedFromEvent) inc.eventPulls = consumeResult.consumedFromEvent;
            if (consumeResult.consumedFromTimed) inc.pulls = consumeResult.consumedFromTimed;
            if (consumeResult.consumedFromSpecial && resolvedGrant) {
              inc[`specialPulls.${resolvedGrant.label ?? resolvedGrant.displayLabel}`] = consumeResult.consumedFromSpecial;
            }
            if (Object.keys(inc).length > 0) {
              await PullQuotaModel.updateOne({ userId: discordUserId }, { $inc: inc }).catch(() => null);
              if (!PullQuotaModel) {
                if (consumeResult.consumedFromEvent) doc.eventPulls = (doc.eventPulls ?? 0) + consumeResult.consumedFromEvent;
                if (consumeResult.consumedFromTimed) doc.pulls = (doc.pulls ?? 0) + consumeResult.consumedFromTimed;
                if (consumeResult.consumedFromSpecial && resolvedGrant) {
                  doc.specialPulls = doc.specialPulls ?? {};
                  doc.specialPulls[resolvedGrant.label ?? resolvedGrant.displayLabel] =
                    (doc.specialPulls[resolvedGrant.label ?? resolvedGrant.displayLabel] ?? 0) + consumeResult.consumedFromSpecial;
                }
                await doc.save().catch(() => null);
              }
            }
          }
        } catch (refundErr) {
          console.error('refund error after draw failure:', refundErr);
        }

        inFlightInteractions.delete(interaction.id);

        const elapsed = Date.now() - gifShownAt;
        if (elapsed < ANIM_MS) await sleep(ANIM_MS - elapsed);

        await interaction.editReply({ embeds: [], attachments: [], content: 'An error occurred while drawing the pack. Your pull has been refunded. Please try again.', components: [] }).catch(() => null);
        await release();
        return;
      }

      displayGuard.stage('writing drawn cards to inventory');
      // --- Persist cards + build page items ---
      const pageItems = [];
      const allNames = [];
      const syToAnnounce = [];
      const now = new Date();

      try {
        // Load the inventory once. The per-user pull lock means another /pull or
        // /multi-pull for this user cannot race this block.
        const inventoryDoc = await User.findOne(
          { id: discordUserId },
          { cards: 1 }
        ).lean();

        if (!inventoryDoc) {
          throw new Error(`User inventory document missing for ${discordUserId}`);
        }

        // Match the command's existing card identity behavior:
        // rarity + normalized, case-insensitive display name.
        const normalizeInventoryName = value =>
          String(value ?? '')
            .replace(/[_\s\-]+/g, ' ')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();

        const makeInventoryKey = (rarity, name) =>
          `${String(rarity ?? '')}\u0000${normalizeInventoryName(name)}`;

        // Keep the first matching stack, which mirrors Mongo's positional "$"
        // behavior used by the old per-card update path.
        const existingByKey = new Map();
        for (const card of Array.isArray(inventoryDoc.cards) ? inventoryDoc.cards : []) {
          const key = makeInventoryKey(card.rarity, card.name);
          if (!existingByKey.has(key)) {
            existingByKey.set(key, {
              _id: card._id,
              count: Number(card.count || 0),
              name: card.name,
              rarity: card.rarity,
            });
          }
        }

        // Group all drawn copies first. This turns hundreds of sequential
        // updateOne/findOne calls into one inventory read + one bulkWrite.
        const grouped = new Map();

        for (let packIndex = 0; packIndex < packs.length; packIndex += 1) {
          for (let cardIndex = 0; cardIndex < packs[packIndex].length; cardIndex += 1) {
            const item = packs[packIndex][cardIndex];
            const { rarity, file } = item;

            const base = path.basename(file);
            const ext = path.extname(base);
            const raw = base.slice(0, base.length - ext.length);
            const displayName = raw.replace(/[_-\s]+/g, ' ').trim();
            const inventoryKey = makeInventoryKey(rarity, displayName);

            if (!SY_ANNOUNCE_EXEMPT_IDS.has(discordUserId) && String(rarity).toUpperCase() === 'SY') {
              syToAnnounce.push({ rarity: 'SY', name: displayName });
            }

            let group = grouped.get(inventoryKey);
            if (!group) {
              const existing = existingByKey.get(inventoryKey) || null;
              group = {
                rarity,
                displayName,
                existing,
                quantity: 0,
              };
              grouped.set(inventoryKey, group);
            }

            group.quantity += 1;

            // Because pulls are displayed in draw order, compute the count this
            // particular copy would have had after the old sequential write.
            const startingCount = Number(group.existing?.count || 0);
            const currentCount = startingCount + group.quantity;

            const encodedUrl = item.relativeImagePath
              ? `${IMAGE_BASE.replace(/\/$/, '')}/${item.relativeImagePath
                  .split('/')
                  .map(encodeURIComponent)
                  .join('/')}`
              : `${IMAGE_BASE.replace(/\/$/, '')}/${encodeURIComponent(rarity)}/${encodeURIComponent(raw)}${path.extname(path.basename(file)) || '.png'}`;

            const visiblePrefix = `[${rarity}] - `;
            const titleBody = `${displayName}`;
            const titleCount = ` - #${currentCount}`;
            const titleLine = `${visiblePrefix}${titleBody}`;

            const cc = resolveCardColor(displayName, rarity);
            const emoji = cc ? getAttributeEmoji(cc) : '';
            const tag = emoji ? ` ${emoji}` : '';

            const listLine = `${visiblePrefix}[${escapeLinkText(titleBody)}](${encodedUrl})${tag}${titleCount}`;

          // Keep the actual selected source file (including .jpg, such as BOO)
          // instead of assuming every rarity has a .png at a synthesized path.
          const localImagePath = path.isAbsolute(String(file))
            ? String(file)
            : (item.relativeImagePath
              ? path.join(process.cwd(), 'assets', 'images', ...String(item.relativeImagePath).split('/'))
              : path.join(process.cwd(), 'assets', 'images', String(rarity), path.basename(String(file))));

            pageItems.push({
              rarity,
              rawName: raw,
              displayName,
              titleLine,
              imageUrl: encodedUrl,
              localImagePath,
              packIndex,
              cardIndex,
              listLine
            });
            allNames.push(listLine);
          }
        }

        const bulkOps = [];
        const newCards = [];

        for (const group of grouped.values()) {
          if (group.existing) {
            const filter = group.existing._id
              ? { id: discordUserId, 'cards._id': group.existing._id }
              : {
                  id: discordUserId,
                  cards: {
                    $elemMatch: {
                      name: {
                        $regex: new RegExp(
                          `^${escapeRegex(
                            group.displayName
                              .replace(/[_\s\-]+/g, ' ')
                              .replace(/\s+/g, ' ')
                              .trim()
                          )}$`,
                          'i'
                        )
                      },
                      rarity: group.rarity
                    }
                  }
                };

            bulkOps.push({
              updateOne: {
                filter,
                update: {
                  $inc: { 'cards.$.count': group.quantity },
                  $set: { 'cards.$.lastAcquiredAt': now }
                }
              }
            });
          } else {
            newCards.push({
              name: group.displayName,
              rarity: group.rarity,
              count: group.quantity,
              firstAcquiredAt: now,
              lastAcquiredAt: now
            });
          }
        }

        if (newCards.length) {
          bulkOps.push({
            updateOne: {
              filter: { id: discordUserId },
              update: { $push: { cards: { $each: newCards } } }
            }
          });
        }

        if (bulkOps.length) {
          const bulkResult = await User.bulkWrite(bulkOps, { ordered: true });

          // Existing stack updates should all match. A mismatch would mean the
          // inventory changed unexpectedly after our single read; fail rather
          // than silently lose cards.
          const expectedExistingUpdates = bulkOps.length - (newCards.length ? 1 : 0);
          if (Number(bulkResult.matchedCount || 0) < expectedExistingUpdates) {
            throw new Error(
              `Inventory changed during multi-pull save: expected ${expectedExistingUpdates} existing stack matches, got ${bulkResult.matchedCount || 0}`
            );
          }
        }
      } catch (err) {
        console.error('atomic update error after consume:', err);

        // refund because we consumed earlier but failed to persist cards
        try {
          const { doc } = await PullQuota.getUpdatedQuota(discordUserId, { frozen });
          if (doc) {
            const inc = {};
            if (consumeResult.consumedFromEvent) inc.eventPulls = consumeResult.consumedFromEvent;
            if (consumeResult.consumedFromTimed) inc.pulls = consumeResult.consumedFromTimed;
            if (consumeResult.consumedFromSpecial && resolvedGrant) {
              inc[`specialPulls.${resolvedGrant.label ?? resolvedGrant.displayLabel}`] = consumeResult.consumedFromSpecial;
            }
            if (Object.keys(inc).length > 0) {
              await PullQuotaModel.updateOne({ userId: discordUserId }, { $inc: inc }).catch(() => null);
              if (!PullQuotaModel) {
                if (consumeResult.consumedFromEvent) doc.eventPulls = (doc.eventPulls ?? 0) + consumeResult.consumedFromEvent;
                if (consumeResult.consumedFromTimed) doc.pulls = (doc.pulls ?? 0) + consumeResult.consumedFromTimed;
                if (consumeResult.consumedFromSpecial && resolvedGrant) {
                  doc.specialPulls = doc.specialPulls ?? {};
                  doc.specialPulls[resolvedGrant.label ?? resolvedGrant.displayLabel] =
                    (doc.specialPulls[resolvedGrant.label ?? resolvedGrant.displayLabel] ?? 0) + consumeResult.consumedFromSpecial;
                }
                await doc.save().catch(() => null);
              }
            }
          }
        } catch (refundErr) {
          console.error('refund error after atomic update failure:', refundErr);
        }

        inFlightInteractions.delete(interaction.id);

        const elapsed = Date.now() - gifShownAt;
        if (elapsed < ANIM_MS) await sleep(ANIM_MS - elapsed);

        await interaction.editReply({ embeds: [], attachments: [], content: 'An error occurred while saving your pull. Your pull has been refunded. Please try again.', components: [] }).catch(() => null);
        await release();
        return;
      }
      
      displayGuard.saved(pageItems);
      displayGuard.stage('inventory saved / HAL rewards');
      const halBonus = await halEvent.rollPullRewards(discordUserId, candyEarned, { skipBoo: true })
        .catch(err => { console.error('[HAL] multi pull rewards failed:', err); return null; });
      const booNames = packs.flatMap(pack => pack.filter(item => item.rarity === 'BOO')
        .map(item => path.parse(item.file).name));
      const xNames = packs.flatMap(pack => pack.filter(item => item.rarity === '???')
        .map(item => path.parse(item.file).name));
      const trickDrops = booNames.filter(isTrickBoo);
      const halRewardNotice = halBonus
        ? `\n\uD83C\uDF83 +${candyEarned} Candy (Balance: ${halBonus.balance})${booNames.length ? ` | BOO extra slot: ${booNames.join(', ')}` : ''}${xNames.length ? ` | ??? special card: ${xNames.join(', ')}` : ''}${trickDrops.length ? `\n🎃 YOU'VE BEEN TRICKED! BanG Dream! guests: ${trickDrops.join(', ')}` : ''}`
        : '';
      if (halMagicianReady) await halEvent.useMagician(discordUserId);

      // --- Build pack-local descriptions and show results ---
      const packDescriptions = packs.map((_, packIndex) => {
        const lines = pageItems.filter(it => it.packIndex === packIndex).map(it => it.listLine);
        return `**Pulled ${amount} pack${amount === 1 ? '' : 's'}**${packIndex === 0 ? halRewardNotice : ''}\n**Pack ${packIndex + 1}**\n${lines.join('\n')}`;
      });

      const elapsedSinceGif = Date.now() - gifShownAt;
      if (elapsedSinceGif < ANIM_MS) await sleep(ANIM_MS - elapsedSinceGif);

      // SEC reveal (also respects queued fast mode)
      const hasSEC = pageItems.some(it => String(it.rarity ?? '').toUpperCase() === 'SEC');
      // --- Update pull stats + pity counter ---
      let nextSinceSEC = 0;

      // ✅ NEW: count unless "no-track". No-force users will keep counting and never force.
      if (!pityNoTrack) {
        nextSinceSEC = runningSinceSEC;
      }

      try {
        const update = {
          $setOnInsert: { id: discordUserId, cards: [], points: 0 },
          $inc: { pulls: amount },
        };

        // ✅ NEW: save pity count for normal users + IDS2; do not save for IDS1
        if (!pityNoTrack) {
          update.$set = { pullsSinceLastSEC: nextSinceSEC };
        }

        await User.updateOne({ id: discordUserId }, update, { upsert: true });
      } catch (e) {
        console.error('[pull] Failed to update pulls/pity:', e);
      }

      function makeEmbed(idx) {
        const it = pageItems[idx];
        const trickReveal = it.rarity === 'BOO' && isTrickBoo(it.displayName)
          ? '🎃 **YOU\'VE BEEN TRICKED!** A BanG Dream! visitor slipped into your BOO pull!\n\n'
          : '';
        
        const cc = resolveCardColor(it.displayName, it.rarity);
        const emoji = cc ? getAttributeEmoji(cc) : '';
        const tag = emoji ? ` ${emoji}` : '';

        if (useSpecial) {
          return new EmbedBuilder()
            .setTitle(`Pack ${it.packIndex + 1}/${amount} • Card ${it.cardIndex + 1} **[${it.rarity}]** - ${it.displayName}${tag}`)
            .setDescription((trickReveal + packDescriptions[it.packIndex]).slice(0, 4096))
            .setColor(0x87CEFA)
            .addFields({ name: 'Special pulls remaining', value: `${consumeResult.remainingSpecial ?? 0}`, inline: true })
            .setImage('attachment://pull-card.png')
            .setURL(it.imageUrl)
            .setFooter({ text: `Pack ${it.packIndex + 1} / ${amount} • Card ${it.cardIndex + 1} / ${packs[it.packIndex].length}\nPull by: ${interaction.user.username}` });
        }

        return new EmbedBuilder()
          .setTitle(`Pack ${it.packIndex + 1}/${amount} • Card ${it.cardIndex + 1} **[${it.rarity}]** - ${it.displayName}${tag}`)
          .setDescription((trickReveal + packDescriptions[it.packIndex]).slice(0, 4096))
          .setColor(0x00BB88)
          .addFields(
            { name: 'Timed pulls remaining', value: `${consumeResult.remainingTimed}`, inline: true },
            { name: 'Event pulls remaining', value: `${consumeResult.remainingEvent}`, inline: true },
          )
          .setImage('attachment://pull-card.png')
          .setURL(it.imageUrl)
          .setFooter({ text: `Pack ${it.packIndex + 1} / ${amount} • Card ${it.cardIndex + 1} / ${packs[it.packIndex].length}\nPull by: ${interaction.user.username}` });
      }

      function makePagePayload(idx, components) {
        return {
          content: null,
          embeds: [makeEmbed(idx)],
          components,
          attachments: [],
          files: [{ attachment: pageItems[idx].localImagePath, name: 'pull-card.png' }],
        };
      }

      const prevBtnEnabled = new ButtonBuilder().setCustomId('prev').setLabel('◀ Prev').setStyle(ButtonStyle.Primary).setDisabled(pageItems.length <= 1);
      const nextBtnEnabled = new ButtonBuilder().setCustomId('next').setLabel('Next ▶').setStyle(ButtonStyle.Primary).setDisabled(pageItems.length <= 1);
      const prevPackBtnEnabled = new ButtonBuilder().setCustomId('prev_pack').setLabel('◀◀ Prev Pack').setStyle(ButtonStyle.Secondary).setDisabled(amount <= 1);
      const nextPackBtnEnabled = new ButtonBuilder().setCustomId('next_pack').setLabel('Next Pack ▶▶').setStyle(ButtonStyle.Secondary).setDisabled(amount <= 1);
      const jumpPackBtnEnabled = new ButtonBuilder().setCustomId('jump_pack').setLabel('Jump Pack').setStyle(ButtonStyle.Secondary).setDisabled(amount <= 1);
      const row = new ActionRowBuilder().addComponents(prevBtnEnabled, nextBtnEnabled, prevPackBtnEnabled, nextPackBtnEnabled, jumpPackBtnEnabled);

      const prevBtnDisabled = new ButtonBuilder().setCustomId('prev').setLabel('◀ Prev').setStyle(ButtonStyle.Primary).setDisabled(true);
      const nextBtnDisabled = new ButtonBuilder().setCustomId('next').setLabel('Next ▶').setStyle(ButtonStyle.Primary).setDisabled(true);
      const prevPackBtnDisabled = new ButtonBuilder().setCustomId('prev_pack').setLabel('◀◀ Prev Pack').setStyle(ButtonStyle.Secondary).setDisabled(true);
      const nextPackBtnDisabled = new ButtonBuilder().setCustomId('next_pack').setLabel('Next Pack ▶▶').setStyle(ButtonStyle.Secondary).setDisabled(true);
      const jumpPackBtnDisabled = new ButtonBuilder().setCustomId('jump_pack').setLabel('Jump Pack').setStyle(ButtonStyle.Secondary).setDisabled(true);
      const disableRow = new ActionRowBuilder().addComponents(prevBtnDisabled, nextBtnDisabled, prevPackBtnDisabled, nextPackBtnDisabled, jumpPackBtnDisabled);

      // First card index for every pack. For an 8-card pack, Pack 2 starts at page 9.
      const firstCardIndexByPack = packs.map((_, packIndex) => pageItems.findIndex(item => item.packIndex === packIndex));

      const textResult = {
        content: `⚠️ All ${pageItems.length} cards across ${amount} pack(s) were saved, but the image preview failed. Only the first pack is listed here; check your inventory for the rest.`,
        embeds: [new EmbedBuilder().setTitle('🎴 Pull results').setDescription(packDescriptions[0].slice(0, 4000)).setColor(0x00BB88)],
        components: [], attachments: [],
      };
      await showSecReveal(interaction, hasSEC, {
        content: null,
        embeds: [new EmbedBuilder()
          .setTitle('SEC multi-pull results')
          .setDescription(packDescriptions[0].slice(0, 4000))
          .setColor(0xFFD700)],
        attachments: [], components: [],
      }, ANIM_MS, 'multi-pull');
      displayGuard.stage('final Discord result upload');
      const display = await showSavedPull(interaction, makePagePayload(0, [row]), textResult, 'multi-pull');
      const message = display.message;
      const plainResult = !display.image;
      resultDisplayed = Boolean(message);
      if (plainResult) {
        // Never attach a paginator whose card-image payloads are failing.
        inFlightInteractions.delete(interaction.id);
        return;
      }

      if (syToAnnounce.length) {
        void announceSyPull(interaction, syToAnnounce);
      }

      void announceKunChanSamaTanSrPlusPull(interaction, pageItems, message);

      if (pageItems.length <= 1) {
        setTimeout(async () => {
          try { await message.edit({ components: [disableRow] }); } catch {}
        }, Math.min(PAGE_TIMEOUT_MS, 10_000));
        inFlightInteractions.delete(interaction.id);
        return;
      }

      const collector = message.createMessageComponentCollector({ filter: (i) => i.user.id === discordUserId, time: PAGE_TIMEOUT_MS });

      let pageIndex = 0;

      collector.on('collect', async (btnInt) => {
        installLocalImageTransport(btnInt);
        try {
          if (btnInt.customId === 'prev') {
            pageIndex = (pageIndex - 1 + pageItems.length) % pageItems.length;
            await btnInt.deferUpdate();
          await btnInt.editReply(makePagePayload(pageIndex, [row]));
            return;
          }
          if (btnInt.customId === 'next') {
            pageIndex = (pageIndex + 1) % pageItems.length;
            await btnInt.deferUpdate();
          await btnInt.editReply(makePagePayload(pageIndex, [row]));
            return;
          }
          if (btnInt.customId === 'prev_pack') {
            const currentPackIndex = pageItems[pageIndex].packIndex;
            const previousPackIndex = (currentPackIndex - 1 + amount) % amount;
            pageIndex = firstCardIndexByPack[previousPackIndex];
            await btnInt.deferUpdate();
          await btnInt.editReply(makePagePayload(pageIndex, [row]));
            return;
          }
          if (btnInt.customId === 'next_pack') {
            const currentPackIndex = pageItems[pageIndex].packIndex;
            const nextPackIndex = (currentPackIndex + 1) % amount;
            pageIndex = firstCardIndexByPack[nextPackIndex];
            await btnInt.deferUpdate();
          await btnInt.editReply(makePagePayload(pageIndex, [row]));
            return;
          }
          if (btnInt.customId === 'jump_pack') {
            const modalId = `jump_pack_modal_${interaction.id}`;
            const packInputId = 'pack_number';
            const modal = new ModalBuilder()
              .setCustomId(modalId)
              .setTitle(`Jump to Pack (1-${amount})`)
              .addComponents(new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId(packInputId)
                  .setLabel(`Pack number (1-${amount})`)
                  .setStyle(TextInputStyle.Short)
                  .setPlaceholder('Example: 2')
                  .setMinLength(1)
                  .setMaxLength(String(amount).length)
                  .setRequired(true)
              ));
            await btnInt.showModal(modal);
            const modalSubmit = await btnInt.awaitModalSubmit({
              filter: modalInt => modalInt.customId === modalId && modalInt.user.id === discordUserId,
              time: 60_000
            }).catch(() => null);
            if (!modalSubmit) return;
            const packNumber = Number(modalSubmit.fields.getTextInputValue(packInputId).trim());
            if (!Number.isInteger(packNumber) || packNumber < 1 || packNumber > amount) {
              await modalSubmit.reply({ content: `Please enter a whole pack number from 1 to ${amount}.`, ephemeral: true });
              return;
            }
            pageIndex = firstCardIndexByPack[packNumber - 1];
            installLocalImageTransport(modalSubmit);
            await modalSubmit.deferUpdate();
            await modalSubmit.editReply(makePagePayload(pageIndex, [row]));
            return;
          }
          await btnInt.reply({ content: 'Unknown action', ephemeral: true });
        } catch (err) {
          console.error('collector interaction error:', err);
        }
      });

      collector.on('end', async () => {
        try { await message.edit({ components: [disableRow] }); } catch {}
        inFlightInteractions.delete(interaction.id);
        // Lock will be released in finally below.
      });

    } catch (outerErr) {
      console.error('unhandled error in /multi-pull:', outerErr);
      if (!resultDisplayed) {
        try {
          await interaction.editReply({
            content: '⚠️ Multi-pull encountered a server error. Check your inventory and pull balance before retrying.',
            embeds: [], attachments: [], components: [],
          });
        } catch (displayErr) {
          console.error('[multi-pull] failed to clear loading GIF after error:', displayErr);
        }
      }
      inFlightInteractions.delete(interaction.id);
    } finally {
      await release();
    }
  },
};

